﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace EMPLOYEEDETAILS
{
    public partial class EMPOLYEEFROM : System.Web.UI.Page
    {

        SqlConnection con = new SqlConnection( "Data Source=SIPL-LT-262;Initial Catalog=EMPLOYEEHR;Integrated Security=True");
        SqlDataAdapter da;
        DataTable dt;
        string GENDER = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (con.State == System.Data.ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();

            if (rdbtn1.Checked == true)
            {
                GENDER = "M";
            }
            else
                if (rdbtn2.Checked == true)
                {
                    GENDER = "F";
                }
        }
        protected void rdbtn1_CheckedChanged(object sender, EventArgs e)
        {
            GENDER = "M";
            Response.Write("Male radio Button Selection changed");

        }

        protected void rdbtn2_CheckedChanged(object sender, EventArgs e)
        {
            GENDER = "F";
            Response.Write("Female radio Button Selection changed");

        }
            protected void SUBMIT_Click(object sender, EventArgs e)
        {
           
               if (con.State == System.Data.ConnectionState.Open)
            {
                              

                string qy = "insert into Employee(EMPID,EMPCODE,EMPNAME,DEPARTMENT,GENDER,BOD,JOININGDATE,PREVEXPERINCE,SALARY,ADDRESSS) values ('" + EMPID.Text.ToString()+"','"+ TXTEMPCODE.Text.ToString() + "','" + EMPNAME.Text.ToString() + "','" + DEPARTMENT.Text.ToString() + "','" + GENDER + "','" + BOD.Text.ToString() + "','" + JOINGDATE.Text.ToString() + "','" + EXPR.Text.ToString() + "','" + SALARY.Text.ToString() + "','" + ADDRESS.Text.ToString() + "')";
                SqlCommand sam = new SqlCommand(qy, con);
                sam.ExecuteNonQuery();
                EMPID.Text = "";
                TXTEMPCODE.Text = "";
                EMPNAME.Text = "";
                DEPARTMENT.Text = "";
                GENDER = "";
                BOD.Text = "";
                JOINGDATE.Text = "";
                EXPR.Text = "";
                SALARY.Text = "";
                ADDRESS.Text = "";
                display();
                if (rdbtn1.Checked)
                {
                    Response.Write("Your Gender is" + rdbtn1.Text + "<br/>");
                }
                else
                {
                    Response.Write("Your Gender is" + rdbtn2.Text + "<br/>");
                }
                
            }
          
             
        }
        public void display()
        {

            Response.Write("values as inserted to database" + "<br/>");
             SqlCommand cmd = con.CreateCommand();
             cmd.CommandType = CommandType.Text;
             cmd.CommandText = "select * from Employee";
             cmd.ExecuteNonQuery();
             DataTable dtbl = new DataTable();
             SqlDataAdapter sect = new SqlDataAdapter("select * from  Employee", con);
             sect.Fill(dtbl);
             Employee.DataSource = dtbl;
             Employee.DataBind();

        }
       

        protected void Button1_Click(object sender, EventArgs e)
        {
            string s = "Data Source=SIPL-LT-262;Initial Catalog=EMPLOYEEHR;Integrated Security=True";
           using ( SqlConnection con1 = new SqlConnection(s))
           {
            con1.Open();
            if (con1.State == System.Data.ConnectionState.Open)
            {
               SqlDataAdapter sect = new SqlDataAdapter("select * from  Employee", con1);
                DataTable dtbl = new DataTable();
                sect.Fill(dtbl);
                Employee.DataSource = dtbl;
                Employee.DataBind();


            }
           }

        }

        protected void ILKSelect_Click(object sender, EventArgs e)
        {
            int EMPID1 = Convert.ToInt32((sender as LinkButton).CommandArgument);
            da = new SqlDataAdapter("select * from Employee where EMPID=" + EMPID1+"", con);
            dt= new DataTable();;
            da.Fill(dt);
             Employee.DataSource = dt;
            Employee.DataBind();
                       
            //Console.WriteLine("Success");
            //display();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete  from Employee where EMPCODE='" + TXTEMPCODE.Text + "'";
            cmd.ExecuteNonQuery();
            EMPID.Text = "";
            display();
                
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update  Employee set EMPID='" + EMPID.Text + "', EMPNAME='" + EMPNAME.Text + "',EMPCODE='" + TXTEMPCODE.Text + "',DEPARTMENT='" + DEPARTMENT.Text + "',GENDER='" + GENDER +"' where EMPID=" + Convert.ToInt32(oldid.Text) + "";
                //"',DEPARTMENT='" + DEPARTMENT.Text + "',GENDER='" + GENDER + "',BOD='" + BOD.Text + "',JOININGDATE='" + JOINGDATE.Text + "',PREVEXPERINCE='" + EXPR + "',SALARY='" + SALARY.Text + "',ADDRESSS='" + ADDRESS.Text + "' where EMPID=" + Convert.ToInt32(oldid.Text) + "";
            cmd.ExecuteNonQuery();
            TXTEMPCODE.Text = "";
            EMPNAME.Text = "";
            DEPARTMENT.Text = "";
            display();
                
        }
       
        }
    }
